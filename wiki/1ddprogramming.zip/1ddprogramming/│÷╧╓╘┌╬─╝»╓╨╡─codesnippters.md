﻿title: 分散在part1中的实例演练归类
prev_title: 本书涉及到的关键标识列表
prev_url: 本书涉及到的关键标识列表.html
next_title: 本书用到的图例
next_url: 本书用到的图例.html

由于mpge实际上是wtgl的一个属集，所以，它的功能保持在演示wtgl的前提下。。未来，可能会出现更强大的mpge

我们保留了src hacking版本作为本书的附书源码，等到part1的源码完成之后，我们可以提出新的mpge rev，非教育导向的rev，而且重发明轮子对于实践能力的培养是巨大的，，全部发明轮子大于，srchacking大于import libs(比如，游戏编程的能力就是能使用引擎脱离引擎进行图形级和作为图形产品级游戏的编程，，首先是通用编程实践)。。

分散在part1中的实例演练归类
\title

实现类：
-----------------

实现一个内存沲
实现一个tcplike udp layer
仿BOOST实现xx series(boost.fs etc..)

实现war3的cellbased terrain
场景拾取

一个binxml的实现

API使用类：
----------------
一个win32下的dx渲染框架
利用qt实现一个mdi


1,用singal实现GUI
2,BOOST。PROTPYTREE实现BINXML
3，

new mpge ver planned
\title====

rewrite mpge based on part1 excesies

futher rewrite to tmpge,,maybe more game algos,,,and made to commeraic

更多程序设计案例举例与练习
\section1

作者的第二本书是《常见领域抽象惯用法》,,maybe第三本书的方向：各领域编程抽象整理汇总,,每天YY一些练习（程序设计案例）来做,,并将其写在书中

本套丛书第一本为《编程新手真言》，第二本为《游戏编程新手真言》，第三本拟为《domain prog design abstract idioms》，这本书将填补市面上it书的空白。
